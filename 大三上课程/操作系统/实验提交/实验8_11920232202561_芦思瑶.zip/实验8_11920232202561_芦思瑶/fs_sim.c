#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>

#define TOTAL_BLOCKS 500
#define BLOCK_SIZE   (2 * 1024) /* 2 KB */
#define MAX_FILES    128

typedef struct {
    char  name[32];
    int   sizeBytes;
    int   indexBlock;
    int   dataBlocks[TOTAL_BLOCKS];
    int   dataCount;
    bool  inUse;
} FileEntry;

/* 位图：1 表示空闲，0 表示占用，块号 1..TOTAL_BLOCKS */
static bool freeMap[TOTAL_BLOCKS + 1];
static FileEntry files[MAX_FILES];

static void init_disk(void) {
    for (int i = 1; i <= TOTAL_BLOCKS; ++i) freeMap[i] = true;
    memset(files, 0, sizeof(files));
}

/* 顺序分配一个空闲块；可改为随机分配 */
static int alloc_block(void) {
    for (int i = 1; i <= TOTAL_BLOCKS; ++i) {
        if (freeMap[i]) {
            freeMap[i] = false;
            return i;
        }
    }
    return -1;
}

static void free_block(int b) {
    if (b >= 1 && b <= TOTAL_BLOCKS) freeMap[b] = true;
}

static FileEntry* find_file(const char* name) {
    for (int i = 0; i < MAX_FILES; ++i) {
        if (files[i].inUse && strcmp(files[i].name, name) == 0) return &files[i];
    }
    return NULL;
}

static FileEntry* new_file_slot(void) {
    for (int i = 0; i < MAX_FILES; ++i) {
        if (!files[i].inUse) return &files[i];
    }
    return NULL;
}

static int ceil_div(int a, int b) {
    return (a + b - 1) / b;
}

static void rollback_blocks(int* blocks, int count) {
    for (int i = 0; i < count; ++i) free_block(blocks[i]);
}

static void create_file(const char* name, int sizeBytes) {
    if (find_file(name)) {
        printf("[WARN] %s already exists\n", name);
        return;
    }
    FileEntry* f = new_file_slot();
    if (!f) {
        printf("[ERR ] file table full\n");
        return;
    }

    int dataNeeded = ceil_div(sizeBytes, BLOCK_SIZE);
    int totalNeeded = dataNeeded + 1; /* +1 for index block */

    int blocks[TOTAL_BLOCKS];
    for (int i = 0; i < totalNeeded; ++i) {
        int b = alloc_block();
        if (b == -1) {
            printf("[ERR ] no free space for %s\n", name);
            rollback_blocks(blocks, i);
            return;
        }
        blocks[i] = b;
    }

    memset(f, 0, sizeof(*f));
    f->inUse = true;
    strncpy(f->name, name, sizeof(f->name) - 1);
    f->sizeBytes = sizeBytes;
    f->indexBlock = blocks[0];
    f->dataCount = dataNeeded;
    for (int i = 0; i < dataNeeded; ++i) f->dataBlocks[i] = blocks[i + 1];
}

static void delete_file(const char* name) {
    FileEntry* f = find_file(name);
    if (!f) return;
    free_block(f->indexBlock);
    for (int i = 0; i < f->dataCount; ++i) free_block(f->dataBlocks[i]);
    memset(f, 0, sizeof(*f));
}

static void print_file(const char* name) {
    FileEntry* f = find_file(name);
    if (!f) return;
    printf("%s size=%.1fKB index=%d data=", name, f->sizeBytes / 1024.0, f->indexBlock);
    for (int i = 0; i < f->dataCount; ++i) {
        printf("%d%s", f->dataBlocks[i], (i + 1 == f->dataCount) ? "" : ",");
    }
    printf("\n");
}

static void print_free(void) {
    int count = 0;
    for (int i = 1; i <= TOTAL_BLOCKS; ++i) if (freeMap[i]) ++count;
    printf("Free blocks: %d\n", count);
    printf("List: ");
    for (int i = 1; i <= TOTAL_BLOCKS; ++i) if (freeMap[i]) printf("%d ", i);
    printf("\n");
}

int main(void) {
    srand((unsigned)time(NULL));
    init_disk();

    /* 1) 生成 50 个 2KB-10KB 文件 */
    for (int i = 1; i <= 50; ++i) {
        int szK = (rand() % 9) + 2; /* 2..10 KB */
        char name[16];
        sprintf(name, "%d.txt", i);
        create_file(name, szK * 1024);
    }

    /* 2) 删除奇数序号文件 */
    for (int i = 1; i <= 50; i += 2) {
        char name[16];
        sprintf(name, "%d.txt", i);
        delete_file(name);
    }

    /* 3) 创建 A-E */
    struct { const char* n; double kb; } specs[] = {
        {"A.txt", 7}, {"B.txt", 5}, {"C.txt", 2}, {"D.txt", 9}, {"E.txt", 3.5}
    };
    for (int i = 0; i < 5; ++i) {
        create_file(specs[i].n, (int)(specs[i].kb * 1024));
    }

    /* 4) 输出 A-E 分配表与空闲块状态 */
    printf("A-E allocation:\n");
    for (int i = 0; i < 5; ++i) print_file(specs[i].n);
    print_free();

    return 0;
}

