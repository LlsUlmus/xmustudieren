using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HtmlAgilityPack;
using HtmlDocument = HtmlAgilityPack.HtmlDocument;

namespace NovelDownloader
{
    public partial class MainForm : Form
    {
        private HttpClient httpClient;
        private string baseUrl = "";
        private List<ChapterInfo> chapters = new List<ChapterInfo>();

        public MainForm()
        {
            InitializeComponent();
            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Add("User-Agent", 
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // 设置默认URL（示例）
            txtUrl.Text = "https://www.bqgl.cc/";
            UpdateStatus("请输入小说目录页URL并点击获取章节列表");
        }

        private async void btnGetChapters_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUrl.Text))
            {
                MessageBox.Show("请输入小说目录页URL", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                btnGetChapters.Enabled = false;
                UpdateStatus("正在获取章节列表...");

                baseUrl = GetBaseUrl(txtUrl.Text);
                string htmlContent = await DownloadHtml(txtUrl.Text);
                
                if (!string.IsNullOrEmpty(htmlContent))
                {
                    chapters = ParseChapters(htmlContent);
                    UpdateChapterList();
                    UpdateStatus($"成功获取 {chapters.Count} 个章节");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"获取章节列表失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                UpdateStatus("获取章节列表失败");
            }
            finally
            {
                btnGetChapters.Enabled = true;
            }
        }

        private async void btnDownload_Click(object sender, EventArgs e)
        {
            if (chapters.Count == 0)
            {
                MessageBox.Show("请先获取章节列表", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (lstChapters.CheckedItems.Count == 0)
            {
                MessageBox.Show("请选择要下载的章节", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                btnDownload.Enabled = false;
                progressBar.Value = 0;
                progressBar.Maximum = lstChapters.CheckedItems.Count;

                var saveDialog = new SaveFileDialog
                {
                    Filter = "文本文件|*.txt",
                    FileName = $"{txtNovelName.Text.Trim()}_章节.txt",
                    Title = "保存小说文件"
                };

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    UpdateStatus("开始下载章节内容...");

                    var selectedChapters = new List<ChapterInfo>();
                    foreach (ChapterInfo item in lstChapters.CheckedItems)
                    {
                        selectedChapters.Add(item);
                    }

                    // 按章节顺序排序
                    selectedChapters = selectedChapters.OrderBy(c => c.Index).ToList();

                    StringBuilder novelContent = new StringBuilder();
                    novelContent.AppendLine($"小说名称：{txtNovelName.Text}");
                    novelContent.AppendLine($"下载时间：{DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                    novelContent.AppendLine("=".PadRight(50, '='));
                    novelContent.AppendLine();

                    int downloadedCount = 0;
                    foreach (var chapter in selectedChapters)
                    {
                        UpdateStatus($"正在下载: {chapter.Title}");

                        string chapterContent = await DownloadChapterContent(chapter.Url);
                        if (!string.IsNullOrEmpty(chapterContent))
                        {
                            novelContent.AppendLine(chapter.Title);
                            novelContent.AppendLine();
                            novelContent.AppendLine(chapterContent);
                            novelContent.AppendLine();
                            novelContent.AppendLine("-".PadRight(30, '-'));
                            novelContent.AppendLine();

                            downloadedCount++;
                        }

                        progressBar.Value++;
                        Application.DoEvents(); // 更新UI
                    }

                    // 保存到文件
                    File.WriteAllText(saveDialog.FileName, novelContent.ToString(), Encoding.UTF8);
                    
                    UpdateStatus($"下载完成！共下载 {downloadedCount} 个章节");
                    MessageBox.Show($"下载完成！\n保存位置: {saveDialog.FileName}\n共下载 {downloadedCount} 个章节", 
                        "完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"下载失败: {ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                UpdateStatus("下载失败");
            }
            finally
            {
                btnDownload.Enabled = true;
                progressBar.Value = 0;
            }
        }

        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstChapters.Items.Count; i++)
            {
                lstChapters.SetItemChecked(i, true);
            }
        }

        private void btnSelectNone_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstChapters.Items.Count; i++)
            {
                lstChapters.SetItemChecked(i, false);
            }
        }

        private void btnSelectFirst5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstChapters.Items.Count; i++)
            {
                lstChapters.SetItemChecked(i, i < 5);
            }
        }

        private string GetBaseUrl(string url)
        {
            try
            {
                Uri uri = new Uri(url);
                return $"{uri.Scheme}://{uri.Host}";
            }
            catch
            {
                return url;
            }
        }

        private async Task<string> DownloadHtml(string url)
        {
            try
            {
                HttpResponseMessage response = await httpClient.GetAsync(url);
                response.EnsureSuccessStatusCode();
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                throw new Exception($"下载页面失败: {ex.Message}");
            }
        }

        private List<ChapterInfo> ParseChapters(string html)
        {
            var chapterList = new List<ChapterInfo>();
            HtmlDocument doc = new HtmlDocument(); // 现在使用的是 HtmlAgilityPack 的 HtmlDocument
            doc.LoadHtml(html);

            // 尝试多种常见的章节选择器
            var chapterNodes = doc.DocumentNode.SelectNodes("//div[@class='listmain']//a") ??
                              doc.DocumentNode.SelectNodes("//div[@class='chapter-list']//a") ??
                              doc.DocumentNode.SelectNodes("//div[@id='list']//a") ??
                              doc.DocumentNode.SelectNodes("//dl[@class='chapterlist']//a");

            if (chapterNodes != null)
            {
                int index = 0;
                foreach (var node in chapterNodes)
                {
                    string title = node.InnerText.Trim();
                    string href = node.GetAttributeValue("href", "");

                    if (!string.IsNullOrEmpty(title) && !string.IsNullOrEmpty(href))
                    {
                        // 处理相对URL
                        if (!href.StartsWith("http"))
                        {
                            if (href.StartsWith("//"))
                            {
                                href = "https:" + href;
                            }
                            else if (href.StartsWith("/"))
                            {
                                href = baseUrl + href;
                            }
                            else
                            {
                                href = baseUrl + "/" + href;
                            }
                        }

                        chapterList.Add(new ChapterInfo
                        {
                            Index = index++,
                            Title = title,
                            Url = href
                        });
                    }
                }
            }

            return chapterList;
        }

        private async Task<string> DownloadChapterContent(string url)
        {
            try
            {
                string html = await DownloadHtml(url);
                HtmlDocument doc = new HtmlDocument(); // 现在使用的是 HtmlAgilityPack 的 HtmlDocument
                doc.LoadHtml(html);

                // 尝试多种常见的内容选择器
                var contentNode = doc.DocumentNode.SelectSingleNode("//div[@id='content']") ??
                                 doc.DocumentNode.SelectSingleNode("//div[@class='content']") ??
                                 doc.DocumentNode.SelectSingleNode("//div[@class='text-content']");

                if (contentNode != null)
                {
                    string content = contentNode.InnerText;
                    // 清理内容
                    content = System.Text.RegularExpressions.Regex.Replace(content, @"\s+", "\r\n    ");
                    content = content.Replace("&nbsp;", " ").Replace("<br>", "\r\n");
                    return content.Trim();
                }

                return "无法解析章节内容";
            }
            catch (Exception ex)
            {
                return $"下载失败: {ex.Message}";
            }
        }

        private void UpdateChapterList()
        {
            lstChapters.Items.Clear();
            foreach (var chapter in chapters.Take(100)) // 限制显示前100章
            {
                lstChapters.Items.Add(chapter, true);
            }
        }

        private void UpdateStatus(string message)
        {
            lblStatus.Text = $"状态: {message}";
            Application.DoEvents();
        }
    }

    public class ChapterInfo
    {
        public int Index { get; set; }
        public string Title { get; set; } = string.Empty; // 添加默认值
        public string Url { get; set; } = string.Empty;   // 添加默认值

        public override string ToString()
        {
            return $"{Index + 1:000}. {Title}";
        }
    }
}