﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;

namespace SnakeGame
{
    // 位置结构
    readonly struct Pos
    {
        public int X { get; }
        public int Y { get; }
        public Pos(int x, int y) { X = x; Y = y; }
        public static bool operator ==(Pos a, Pos b) => a.X == b.X && a.Y == b.Y;
        public static bool operator !=(Pos a, Pos b) => !(a == b);
        public override bool Equals(object? obj) => obj is Pos p && this == p;
        public override int GetHashCode() => HashCode.Combine(X, Y);
    }

    class Program
    {
      
        const int Width = 50;
        const int Height = 25;

        // 符号
        const char BorderChar = '#';
        const char SnakeChar = '*';
        const char FoodChar = '@';
        const char DeadChar = 'x';

        // 随机数&输入
        static readonly Random _rand = new Random();

        // 蛇的身体：头在队尾
        static readonly LinkedList<Pos> _snake = new LinkedList<Pos>();
        static Pos _dir = new Pos(1, 0); // 初始向右
        static Pos _food;

        // 分数 & 速度
        static int _score = 0;
        static double _stepMs = 140;   // 初始每步毫秒（越小越快）
        const double MinStepMs = 60;   // 最快
        const double SpeedGain = 8;    // 每次吃食物提速多少毫秒

        // 占位：快速判断身体碰撞
        static readonly HashSet<Pos> _bodySet = new HashSet<Pos>();

        static void Main()
        {
            Console.CursorVisible = false;
            Console.Clear();
            Console.SetWindowSize(Math.Max(Width + 2, 60), Math.Max(Height + 4, 30));
            Console.SetBufferSize(Console.WindowWidth, Console.WindowHeight);

            DrawBorder();
            InitSnake();
            SpawnFood();
            RenderScore();

            var sw = Stopwatch.StartNew();
            long prev = 0;

            while (true)
            {
                // 1) 输入（非阻塞）
                if (Console.KeyAvailable)
                {
                    var key = Console.ReadKey(true).Key;
                    if (key == ConsoleKey.Escape) return;

                    // 方向变更（阻止直接反向）
                    var newDir = _dir;
                    switch (key)
                    {
                        case ConsoleKey.UpArrow: newDir = new Pos(0, -1); break;
                        case ConsoleKey.DownArrow: newDir = new Pos(0, 1); break;
                        case ConsoleKey.LeftArrow: newDir = new Pos(-1, 0); break;
                        case ConsoleKey.RightArrow: newDir = new Pos(1, 0); break;
                    }
                    if (!IsReverse(newDir, _dir)) _dir = newDir;

                    // 清空输入缓冲，避免一次读取过多方向
                    while (Console.KeyAvailable) Console.ReadKey(true);
                }

                // 2) 按时钟推进一格
                if (sw.ElapsedMilliseconds - prev >= _stepMs)
                {
                    prev = sw.ElapsedMilliseconds;
                    if (!Step()) break; // 碰撞 → 结束
                }

                Thread.Sleep(1); // 让出 CPU
            }

            // 失败效果：整条蛇显示为 'x'（提高要求1）
            foreach (var p in _snake) Draw(p, DeadChar);
            Console.SetCursorPosition(2, Height + 1);
            Console.WriteLine($"Game Over! Score = {_score}. 按任意键退出...");
            Console.ReadKey(true);
        }

        // —————————— 核心逻辑 ——————————

        static void InitSnake()
        {
            _snake.Clear(); _bodySet.Clear();
            var start = new Pos(Width / 2, Height / 2);
            // 初始长度 4
            for (int i = 3; i >= 0; i--)
            {
                var p = new Pos(start.X - i, start.Y);
                _snake.AddLast(p);
                _bodySet.Add(p);
                Draw(p, SnakeChar);
            }
        }

        static void SpawnFood()
        {
            while (true)
            {
                var p = new Pos(_rand.Next(1, Width - 1), _rand.Next(1, Height - 1));
                if (!_bodySet.Contains(p))
                {
                    _food = p;
                    Draw(p, FoodChar);
                    return;
                }
            }
        }

        static bool Step()
        {
            var head = _snake.Last!.Value;
            var next = new Pos(head.X + _dir.X, head.Y + _dir.Y);

            // 边界碰撞
            if (next.X <= 0 || next.X >= Width - 0 || next.Y <= 0 || next.Y >= Height - 0)
                return false;

            // 身体碰撞
            if (_bodySet.Contains(next)) return false;

            // 前进：加头
            _snake.AddLast(next);
            _bodySet.Add(next);
            Draw(next, SnakeChar);

            // 食物判定
            if (next == _food)
            {
                _score += 10;
                RenderScore();
                // 提速
                _stepMs = Math.Max(MinStepMs, _stepMs - SpeedGain);
                SpawnFood(); // 再生食物
                // 不移除尾巴 → 自然变长
            }
            else
            {
                // 普通移动：去尾
                var tail = _snake.First!.Value;
                _snake.RemoveFirst();
                _bodySet.Remove(tail);
                Draw(tail, ' '); // 擦除尾巴
            }

            return true;
        }

        // —————————— 绘制 & UI ——————————

        static void DrawBorder()
        {
            // 上下边
            for (int x = 0; x < Width; x++)
            {
                Set(x, 0, BorderChar);
                Set(x, Height - 1, BorderChar);
            }
            // 左右边
            for (int y = 0; y < Height; y++)
            {
                Set(0, y, BorderChar);
                Set(Width - 1, y, BorderChar);
            }
        }

        static void RenderScore()
        {
            Console.SetCursorPosition(2, Height); // 边框下方一行
            Console.Write($"Score: {_score,-6}  Speed(ms/step): {_stepMs,5:0}");
        }

        static void Draw(Pos p, char c) => Set(p.X, p.Y, c);

        static void Set(int x, int y, char c)
        {
            Console.SetCursorPosition(x, y);
            Console.Write(c);
        }

        static bool IsReverse(Pos a, Pos b) => (a.X + b.X == 0 && a.Y + b.Y == 0);
    }
}
