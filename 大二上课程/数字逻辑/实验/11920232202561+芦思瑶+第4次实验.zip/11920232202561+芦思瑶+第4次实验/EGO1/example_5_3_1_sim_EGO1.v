//����5.2�ķ������

`timescale 1ns / 1ps	

module example_5_3_1_sim();

    reg cp, x, m;
    
    wire ny1, z;

    reg rd;
    reg  y1;
                               
    example_5_3_1 U(.cp(cp), .x(x), .m(m),.rd(rd),  .y1(y1), .ny1(ny1), .z(z));

    initial begin
         #0
         cp=0;
         rd=0;
         x=0;
         m=0;
        y1=0;

         #5
         rd=1;

         #20     
         x=0;
        m=1;

         #20
        x=1; 
        m=0;

         #20 
         x=1;
        m=1;

         #20 
         x=0;
         m=1;

         #20 
         x=1;
         m=1;

         #20 
         x=1;
         m=0;

         #20 
         x=0;
         m=0;
    end
    
    always #10 cp <= ~cp;

    always #20 begin  y1 <= ny1; end

endmodule