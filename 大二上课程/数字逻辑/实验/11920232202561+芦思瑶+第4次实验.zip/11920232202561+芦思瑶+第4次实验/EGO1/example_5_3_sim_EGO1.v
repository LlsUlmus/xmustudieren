

`timescale 1ns / 1ps	

module example_5_2_sim();

    reg cp, x, m;
    wire  ny1;
    wire z;

    reg rd;
    wire ny1n;
    reg y1;
    reg y1n;
                               
    example_5_2 U(.cp(cp), .x(x), .m(m), .rd(rd), .y1(y1), .y1n(y1n), .ny1(ny1), .ny1n(ny1n), .z(z));

    initial begin
         #0
         cp=0;
         rd=0;
         x=0;

         #5
         rd=1;
          
        #20     
         x=0;
        m=1;

         #20
        x=1; 
        m=0;

         #20 
         x=1;
        m=1;

         #20 
         x=0;
         m=1;

         #20 
         x=1;
         m=1;

         #20 
         x=1;
         m=0;

         #20 
         x=0;
         m=0;
    end

           
    always #10 cp <= ~cp;

    always #20 begin  y1 <= ny1; y1n <= ny1n; end

endmodule