
`timescale 1ns / 1ps	

module xor_gate(
    input a,
    input b,
    output f                               
);
    reg y;
    always @(*)                        //��Ϊ������ʽ
    begin
       y <= a ^ b; 
    end
    assign f = y;
endmodule

module nand_gate(
    input a,
    input b,
    output f                               
);
    reg y;
    always @(*)                        //��Ϊ������ʽ
    begin
        y <= ~(a & b);
           end
    assign f = y;
endmodule

module d_flip_flop(
    input d,                               	  
    input cp,     
    input rd,                                                    
    output q, qn		
);
    reg y;
    always @(posedge cp  or negedge rd)                     //��Ϊ������ʽ
    begin
       if(rd==0)  	                                           	        //  rd=0         y=0
                y <= 0;
       else                                                                           //  rd=1            
                case(d)
	               0: y <= 0;			      //  d  =  0       y=0
	               1: y <= 1;			      //  d  =  1       y=1
                endcase
    end
    assign  q= y;
    assign qn = ~y;
endmodule

module example_5_3(
    input cp,	
    input x,
    input m,      
    input rd,                         		 
    input  y1, y1n,			 
    output  ny1, ny1n, z    		 	          
);
    wire  d2, d1, d3, d4, d5;
    d_flip_flop U1(.d(d3),.cp(cp),.rd(rd),.q(ny1),.qn(ny1n));
    xor_gate U2(.a(x),.b(m),.f(d1));	
    xor_gate U3(.a(d1),.b(y),.f(z));		
    nand_gate U4(.a(x),.b(m),.f(d3));				//�ṹ��������ʽ
    nand_gate U5(.a(y),.b(d1),.f(d4));	
    nand_gate U6(.a(d3),.b(d4),.f(d5));		//�ṹ��������ʽ
endmodule