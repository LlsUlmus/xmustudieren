`timescale 1ns / 1ps	

module nand2_gate(
    input a,
    input b,
    output reg f                               
);
    always @(*)                        //行为描述方式
    begin
        f <= ~(a | b); 
    end
endmodule



module not_gate(
    input a,
    output reg f                               
);
    always @(*)                        //行为描述方式
    begin
        f <= ~a; 
    end
endmodule

module example_4_12a(
    input sw_pin[7:0],                               		 //8个拨动开关
    output [15:0] led_pin    		 	//16个led灯            
);
    wire p1, p2, p3, p4, p5, p6, p7, p8;

    not_gate U1(.a(sw_pin[0]),.f(p1));					//结构化描述方式
    not_gate U2(.a(sw_pin[1]),.f(p2));					//结构化描述方式
  
    nand2_gate U3(.a(sw_pin[6]),.b(p1),.f(p3));	       //结构化描述方式
    nand2_gate U4(.a(sw_pin[7]),.b(p2),.f(p4));			//结构化描述方式
     nand2_gate U5(.a(p3),.b(p4),.f(led_pin[0]));			//结构化描述方式

endmodule