`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2021/05/03 16:06:57
// Design Name: 
// Module Name: led
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module led(
    input   clk,
    input   rst,
    input   statue,
    output reg[7:0]led2
    );

    integer led_cnt;
    
    always @(posedge clk or negedge rst) begin
        if(!rst)
            begin
            led_cnt <= 0;
            led2[7:0]=8'b01010101;
            end
        else if(statue==0 && led_cnt>=100_000_000)
            begin
            led_cnt<=0;
            led2[7:0]=~led2[7:0];
            end
        else if(statue==1 && led_cnt>=33_333_333)
            begin
            led_cnt<=0;
            led2[7:0]=~led2[7:0];
            end
        else    led_cnt <= led_cnt+1;
    end
endmodule
