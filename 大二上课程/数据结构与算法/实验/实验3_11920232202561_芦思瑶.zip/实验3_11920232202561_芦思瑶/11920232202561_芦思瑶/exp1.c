#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

#define MAX_VERTICES 100
bool visited[MAX_VERTICES];  

// ͼ���ڽӾ����ʾ
typedef struct Graph {
    char Vex[MAX_VERTICES];    // ��������
    int Edge[MAX_VERTICES][MAX_VERTICES]; // �ڽӾ���
    int vexnum;               // ������
    int edgenum;              // ����
} MGraph;

int FindVex(MGraph G, char x);
void CreateMGraph(MGraph* G);
void PrintMGraph(MGraph G);

void DFS(MGraph G, int v);
void DFSCheck(MGraph G);
void BFS(MGraph G, int v);
void BFSCheck(MGraph G);
void ResetVisit(int vexnum);

int main() {
    MGraph G;
    CreateMGraph(&G);
    PrintMGraph(G);

    char start;
    printf("�����������ͨͼ����ʼ�㣺\n");
    scanf(" %c", &start);
    int v = FindVex(G, start);

    printf("������ȱ�����\n");
    ResetVisit(G.vexnum);
    DFS(G, v);
    printf("\n");

    printf("������ȱ�����\n");
    ResetVisit(G.vexnum);
    BFS(G, v);
    printf("\n");

    return 0;
}


// ͼ�Ĳ���ʵ��
int FindVex(MGraph G, char x) {
    for (int i = 0; i < G.vexnum; i++) {
        if (G.Vex[i] == x)
            return i;
    }
    return -1;
}

void CreateMGraph(MGraph* G) {
    printf("�����붥������\n");
    scanf("%d", &G->vexnum);
    printf("���������:\n");
    scanf("%d", &G->edgenum);

    printf("�����붥����Ϣ:\n");
    for (int i = 0; i < G->vexnum; i++) {
        scanf(" %c", &G->Vex[i]);
    }

    // ��ʼ���ڽӾ���
    for (int i = 0; i < G->vexnum; i++) {
        for (int j = 0; j < G->vexnum; j++) {
            G->Edge[i][j] = 0;
        }
    }

    printf("������ÿ���ߵ��������㣺\n");
    for (int k = 0; k < G->edgenum; k++) {
        char u, v;
        scanf(" %c %c", &u, &v);
        int i = FindVex(*G, u);
        int j = FindVex(*G, v);
        if (i != -1 && j != -1) {
            G->Edge[i][j] = 1;
            G->Edge[j][i] = 1;
        }
        else {
            printf("����������������룡\n");
            k--;
        }
    }
}

void PrintMGraph(MGraph G) {
    printf("�ڽӾ������£�\n  ");
    for (int i = 0; i < G.vexnum; i++) {
        printf("%c ", G.Vex[i]);
    }
    printf("\n");

    for (int i = 0; i < G.vexnum; i++) {
        printf("%c ", G.Vex[i]);
        for (int j = 0; j < G.vexnum; j++) {
            printf("%d ", G.Edge[i][j]);
        }
        printf("\n");
    }
}

// ����ʵ��
void ResetVisit(int vexnum) {
    for (int i = 0; i < vexnum; i++) {
        visited[i] = false;
    }
}

void DFS(MGraph G, int v) {
    printf("%c ", G.Vex[v]);
    visited[v] = true;
    for (int w = 0; w < G.vexnum; w++) {
        if (G.Edge[v][w] && !visited[w]) {
            DFS(G, w);
        }
    }
}

void DFSCheck(MGraph G) {
    for (int i = 0; i < G.vexnum; i++) {
        if (!visited[i]) {
            DFS(G, i);
        }
    }
}

void BFS(MGraph G, int v) {
    int queue[MAX_VERTICES];
    int front = 0, rear = 0;

    printf("%c ", G.Vex[v]);
    visited[v] = true;
    queue[rear++] = v;

    while (front != rear) {
        int u = queue[front++];
        for (int w = 0; w < G.vexnum; w++) {
            if (G.Edge[u][w] && !visited[w]) {
                printf("%c ", G.Vex[w]);
                visited[w] = true;
                queue[rear++] = w;
            }
        }
    }
}

void BFSCheck(MGraph G) {
    for (int i = 0; i < G.vexnum; i++) {
        if (!visited[i]) {
            BFS(G, i);
        }
    }
}

