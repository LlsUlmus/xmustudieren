#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

#define MAX_VERTICES 100
bool visited[MAX_VERTICES];  // ��־����

typedef struct QNode 
{
    int data;
    struct QNode* next;
} QNode;

typedef struct {
    QNode* head;
    QNode* tail;
} Queue;

typedef struct AdjNode 
{
    int v;                   
    struct AdjNode* next;   
} AdjNode;

typedef struct VexNode 
{
    char data;               
    AdjNode* first;          
    AdjNode* last;          
} VexNode;

typedef struct Graph 
{
    VexNode Vex[MAX_VERTICES]; // ��������
    int vexnum;                // ������
    int edgenum;               // ����
} ALGraph;

void QueueInit(Queue* pq);
void QueueDestroy(Queue* pq);
void QueuePush(Queue* pq, int x);
void QueuePop(Queue* pq);
int QueueFront(Queue* pq);
bool QueueEmpty(Queue* pq);

int FindVex(ALGraph G, char x);
void InsertEdge(ALGraph* G, int i, int j);
void CreateALGraph(ALGraph* G);
void PrintALGraph(ALGraph G);

void DFS(ALGraph G, int v);
void DFSCheck(ALGraph G);
void BFS(ALGraph G, int v);
void BFSCheck(ALGraph G);
void ResetVisit(int vexnum);

int main() 
{
    ALGraph G;
    CreateALGraph(&G);
    PrintALGraph(G);

    char start;
    printf("�����������ͨͼ����ʼ�㣺\n");
    scanf(" %c", &start);
    int v = FindVex(G, start);

    printf("������ȱ�����\n");
    ResetVisit(G.vexnum);
    DFS(G, v);
    printf("\n");

    printf("������ȱ�����\n");
    ResetVisit(G.vexnum);
    BFS(G, v);
    printf("\n");

    return 0;
}


void QueueInit(Queue* pq) 
{
    assert(pq);
    pq->head = pq->tail = NULL;
}

void QueueDestroy(Queue* pq) 
{
    assert(pq);
    QNode* cur = pq->head;
    while (cur) {
        QNode* next = cur->next;
        free(cur);
        cur = next;
    }
    pq->head = pq->tail = NULL;
}

void QueuePush(Queue* pq, int x) 
{
    assert(pq);
    QNode* newNode = (QNode*)malloc(sizeof(QNode));
    assert(newNode);
    newNode->data = x;
    newNode->next = NULL;
    if (pq->head == NULL) {
        pq->head = pq->tail = newNode;
    }
    else {
        pq->tail->next = newNode;
        pq->tail = newNode;
    }
}

void QueuePop(Queue* pq) 
{
    assert(pq && pq->head);
    QNode* next = pq->head->next;
    free(pq->head);
    pq->head = next;
    if (!pq->head) {
        pq->tail = NULL;
    }
}

int QueueFront(Queue* pq) 
{
    assert(pq && pq->head);
    return pq->head->data;
}

bool QueueEmpty(Queue* pq) 
{
    return pq->head == NULL;
}

int FindVex(ALGraph G, char x) 
{
    for (int i = 0; i < G.vexnum; i++) {
        if (G.Vex[i].data == x)
            return i;
    }
    return -1;
}

void InsertEdge(ALGraph* G, int i, int j) 
{
    AdjNode* newNode = (AdjNode*)malloc(sizeof(AdjNode));
    assert(newNode);
    newNode->v = j;
    newNode->next = NULL;
    if (G->Vex[i].first == NULL) {
        G->Vex[i].first = G->Vex[i].last = newNode;
    }
    else {
        G->Vex[i].last->next = newNode;
        G->Vex[i].last = newNode;
    }
}

void CreateALGraph(ALGraph* G) 
{
    printf("�����붥������\n");
    scanf("%d", &G->vexnum);
    printf("���������:\n");
    scanf("%d", &G->edgenum);

    printf("�����붥����Ϣ:\n");
    for (int i = 0; i < G->vexnum; i++) {
        scanf(" %c", &G->Vex[i].data);
        G->Vex[i].first = G->Vex[i].last = NULL;
    }

    printf("������ÿ���ߵ��������㣺\n");
    for (int k = 0; k < G->edgenum; k++) {
        char u, v;
        scanf(" %c %c", &u, &v);
        int i = FindVex(*G, u);
        int j = FindVex(*G, v);
        if (i != -1 && j != -1) {
            InsertEdge(G, i, j);
            InsertEdge(G, j, i); // ����ͼ��˫�����
        }
        else {
            printf("����������������룡\n");
            k--;
        }
    }
}

void PrintALGraph(ALGraph G) 
{
    printf("�ڽӱ����£�\n");
    for (int i = 0; i < G.vexnum; i++) {
        AdjNode* cur = G.Vex[i].first;
        printf("%c: ", G.Vex[i].data);
        while (cur) {
            printf("---->%c ", G.Vex[cur->v].data);
            cur = cur->next;
        }
        printf("\n");
    }
}

// ����ʵ��
void ResetVisit(int vexnum) 
{
    for (int i = 0; i < vexnum; i++) {
        visited[i] = false;
    }
}

void DFS(ALGraph G, int v) {
    printf("%c ", G.Vex[v].data);
    visited[v] = true;
    AdjNode* cur = G.Vex[v].first;
    while (cur) {
        int w = cur->v;
        if (!visited[w]) {
            DFS(G, w);
        }
        cur = cur->next;
    }
}

void DFSCheck(ALGraph G) 
{
    for (int i = 0; i < G.vexnum; i++) {
        if (!visited[i]) {
            DFS(G, i);
        }
    }
}

void BFS(ALGraph G, int v) 
{
    Queue q;
    QueueInit(&q);
    printf("%c ", G.Vex[v].data);
    visited[v] = true;
    QueuePush(&q, v);
    while (!QueueEmpty(&q)) {
        int u = QueueFront(&q);
        QueuePop(&q);
        AdjNode* cur = G.Vex[u].first;
        while (cur) {
            int w = cur->v;
            if (!visited[w]) {
                printf("%c ", G.Vex[w].data);
                visited[w] = true;
                QueuePush(&q, w);
            }
            cur = cur->next;
        }
    }
    QueueDestroy(&q);
}

void BFSCheck(ALGraph G) 
{
    for (int i = 0; i < G.vexnum; i++) {
        if (!visited[i]) {
            BFS(G, i);
        }
    }
}

