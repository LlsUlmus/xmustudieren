#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>  
#include <stdlib.h>  

typedef struct BiTNode
{
    int data;
    struct BiTNode* Lchild;
    struct BiTNode* Rchild;
} BiTNode, * BiTree;

BiTree Creat();
int Depth(BiTNode* root);
void InOrderTraverse(BiTNode* root);
void PreOrderTraverse(BiTNode* root);
void PostOrderTraverse(BiTNode* root);
BiTNode* search(BiTNode* root, int x);
void DeleteSubtree(BiTNode** root, int x, int lr);
void Destroy(BiTNode* root);

int main()
{
    BiTree root = Creat(); // ����  
    printf("Depth: %d\n", Depth(root)); // ���  
    printf("�������\n");
    InOrderTraverse(root); // ������� ��ӡ  
    printf("\n");
    printf("ǰ�����\n");
    PreOrderTraverse(root); // ǰ����� ��ӡ  
    printf("\n");
    printf("�������\n");
    PostOrderTraverse(root); // ������� ��ӡ  
    printf("\n");
    int lr;
    int key;
    printf("����Ҫɾ���ڵ��ֵ��");
    scanf("%d", &key);
    printf("lrΪ0ɾ����������1ɾ����������");
    scanf("%d", &lr);
    DeleteSubtree(&root, key, lr); // ɾ������
    printf("ǰ�����\n");
    PreOrderTraverse(root); // ǰ����� ��ӡ  
    printf("\n");
    Destroy(root);
    return 0;
}

BiTree Creat()
{
    int num;
    printf("����ڵ�ֵ��-1��ʾ�սڵ㣩��");
    scanf("%d", &num);
    if (num == -1) {
        return NULL;
    }
    else {
        BiTNode* root = (BiTNode*)malloc(sizeof(BiTNode));
        if (root == NULL) {
            printf("����ʧ��\n");
            exit(1);
        }
        root->data = num;
        printf("������ڵ�ֵ��-1��ʾ�սڵ㣩��");
        root->Lchild = Creat();
        printf("�����ҽڵ�ֵ��-1��ʾ�սڵ㣩��");
        root->Rchild = Creat();
        return root;
    }
}

int Depth(BiTNode* root) {
    if (!root) {
        return 0;
    }
    else {
        int leftDepth = Depth(root->Lchild);
        int rightDepth = Depth(root->Rchild);
        return (leftDepth > rightDepth ? leftDepth : rightDepth) + 1;
    }
}

void InOrderTraverse(BiTNode* root) {
    if (root != NULL) {
        InOrderTraverse(root->Lchild);
        printf("%d ", root->data);
        InOrderTraverse(root->Rchild);
    }
    //printf("\n");
}

void PreOrderTraverse(BiTNode* root) {
    if (root != NULL) {
        printf("%d ", root->data);
        PreOrderTraverse(root->Lchild);
        PreOrderTraverse(root->Rchild);
    }
    //printf("\n");
}

void PostOrderTraverse(BiTNode* root) {
    if (root != NULL) {
        PostOrderTraverse(root->Lchild);
        PostOrderTraverse(root->Rchild);
        printf("%d ", root->data);
    }
    //printf("\n");
}

BiTNode* search(BiTNode* root, int x) {
    if (root == NULL) {
        return NULL;
    }
    else if (root->data == x) {
        return root;
    }
    else {
        BiTNode* leftResult = search(root->Lchild, x);
        if (leftResult != NULL) {
            return leftResult;
        }
        return search(root->Rchild, x);
    }
}

void DeleteSubtree(BiTNode** root, int x, int lr) {
    BiTNode* temp = search(*root, x);
    if (temp != NULL) {
        if (lr == 0 && temp->Lchild != NULL) {
            BiTNode* toDelete = temp->Lchild;
            temp->Lchild = NULL;
        }
        else if (lr == 1 && temp->Rchild != NULL) {
            BiTNode* toDelete = temp->Rchild;
            temp->Rchild = NULL;
        }
    }
}

void Destroy(BiTNode* root) {
    if (root != NULL) {
        Destroy(root->Lchild);
        Destroy(root->Rchild);
        free(root);
    }
}