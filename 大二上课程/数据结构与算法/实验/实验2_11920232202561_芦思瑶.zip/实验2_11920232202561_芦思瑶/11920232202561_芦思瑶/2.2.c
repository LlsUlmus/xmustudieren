#define _CRT_SECURE_NO_WARNINGS 1  
#include <stdio.h>  
#include <stdlib.h>  
#include <string.h>  

typedef struct HNode
{
    char data;        // �ַ�����
    int weight;       // Ȩֵ
    int pa;           // ���ڵ�����
    int lc, rc;       // ���Һ��ӽڵ�����
    char* code;       // ��̬����Ĺ���������
} HNode, * HuffmanTree;

HuffmanTree creat(int n)
{
    HuffmanTree H;
    if (n <= 1) return NULL;
    H = (HNode*)malloc((2 * n) * sizeof(HNode));
    if (!H) return NULL; // ����ڴ�����Ƿ�ɹ�

    for (int i = 1; i <= n; i++)
    {
        char ch;
        int wgt;
        if (scanf(" %c %d", &ch, &wgt) != 2) 
        {
            printf("�����ʽ����\n");
            free(H);
            return NULL;
        }
        H[i].data = ch;
        H[i].weight = wgt;
        H[i].lc = 0;
        H[i].rc = 0;
        H[i].pa = 0;
        H[i].code = NULL;
    }

    // ��ʼ�����ĺ����ڵ�
    for (int i = n + 1; i <= 2 * n - 1; i++) {
        H[i].data = '\0';
        H[i].weight = 0;
        H[i].pa = 0;
        H[i].lc = 0;
        H[i].rc = 0;
        H[i].code = NULL;
    }

    return H;
}

void select(HuffmanTree H, int m, int* s1, int* s2) {
    int min1 = 9999, min2 = 9999;
    *s1 = *s2 = -1; // ��ʼ�� s1 �� s2

    for (int i = 1; i <= m; i++)
    {
        if (H[i].pa == 0) // δ�����ʵĽڵ�
        {
            if (H[i].weight < min1)
            {
                min2 = min1;
                *s2 = *s1;
                min1 = H[i].weight;
                *s1 = i;
            }
            else if (H[i].weight < min2)
            {
                min2 = H[i].weight;
                *s2 = i;
            }
        }
    }
}

void generate(HuffmanTree H, int n)
{
    for (int i = 1; i <= n; i++)
    {
        int j = i, k = 0;
        char* code = (char*)malloc(1010 * sizeof(char));
        if (!code) return;
        memset(code, 0, 1010);

        while (H[j].pa != 0)
        {
            code[k++] = (H[H[j].pa].lc == j) ? '0' : '1';
            j = H[j].pa;
        }
        code[k] = '\0';

        // ��ת
        for (int l = 0; l < k / 2; l++) {
            char temp = code[l];
            code[l] = code[k - 1 - l];
            code[k - 1 - l] = temp;
        }
        printf("%c: %s\n", H[i].data, code);
        free(code);
    }
}

HuffmanTree manu(HuffmanTree H, int n)
{
    int m = 2 * n - 1;
    int s1, s2;
    for (int i = n + 1; i <= m; i++)
    {
        select(H, i - 1, &s1, &s2);
        if (s1 == -1 || s2 == -1) {
            printf("δ�ҵ���СȨֵ�ڵ�\n");
            return H;
        }
        H[s1].pa = H[s2].pa = i;
        H[i].lc = s1;
        H[i].rc = s2;
        H[i].weight = H[s1].weight + H[s2].weight;
        H[i].data = '\0';
    }
    generate(H, n);
    return H;
}

int main() 
{
    HuffmanTree T;
    int n;
    printf("������Ҫ��������ݸ���\n");
    if (scanf("%d", &n) != 1 || n <= 1) 
    {
        printf("���ݸ����������1\n");
        return 1;
    }
    printf("������ÿ���ڵ���ַ���Ȩֵ\n");
    T = creat(n);
    if (T == NULL) 
    {
        printf("�ڴ����ʧ��\n");
        return 1; 
    }
    T = manu(T, n);
    free(T);
    return 0;
}

