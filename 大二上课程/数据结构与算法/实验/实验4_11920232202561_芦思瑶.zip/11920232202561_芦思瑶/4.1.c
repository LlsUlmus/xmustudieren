//#define _CRT_SECURE_NO_WARNINGS 1
//#include <stdio.h>
//#define MAX_VERTICES 100
//
//typedef struct Graph {
//    int n; // ������
//    char vex[MAX_VERTICES]; 
//    int edgenum; 
//    int A[MAX_VERTICES][MAX_VERTICES]; 
//} MGraph;
//
//void CreatMGraph(MGraph* G);
//void PrintMGraph(MGraph G);
//int FindVex(MGraph G, char x);
//void Prim(MGraph G, char c);
//
//int main() {
//    MGraph G;
//    CreatMGraph(&G);
//    PrintMGraph(G);
//    printf("��������ʼ�㣺\n");
//    char c; 
//    getchar(); 
//    scanf("%c", &c);
//    printf("��С������Ϊ��\n");
//    Prim(G, c);
//    return 0;
//}
//
//int FindVex(MGraph G, char x) {
//    for (int i = 0; i < G.n; i++) {
//        if (x == G.vex[i]) {
//            return i;
//        }
//    }
//    return -1;
//}
//
//void CreatMGraph(MGraph* G) {
//    printf("�����붥������\n");
//    scanf("%d", &G->n);
//    printf("�����������\n");
//    scanf("%d", &G->edgenum);
//    printf("�����붥����Ϣ��\n");
//    for (int i = 0; i < G->n; i++) {
//        getchar(); 
//        scanf("%c", &G->vex[i]);
//    }
//
//    // ��ʼ���ڽӾ���
//    for (int i = 0; i < G->n; i++) {
//        for (int j = 0; j < G->n; j++) {
//            G->A[i][j] = 99999; 
//        }
//    }
//    printf("������ÿ���ߵ��������㼰Ȩֵ��\n");
//    for (int k = 0; k < G->edgenum; k++) {
//        char a, b;
//        int weight;
//        scanf(" %c %c %d", &a, &b, &weight); 
//        int i = FindVex(*G, a);
//        int j = FindVex(*G, b);
//        if (i != -1 && j != -1) {
//            G->A[i][j] = weight;
//            G->A[j][i] = weight; 
//        }
//        else {
//            printf("����������������룡\n");
//            k--; 
//        }
//    }
//}
//
//void PrintMGraph(MGraph G) {
//    printf("�ڽӾ������£�\n  ");
//    for (int i = 0; i < G.n; i++) {
//        printf("%c ", G.vex[i]);
//    }
//    printf("\n");
//
//    for (int i = 0; i < G.n; i++) {
//        printf("%c ", G.vex[i]);
//        for (int j = 0; j < G.n; j++) {
//            printf("%d ", G.A[i][j]);
//        }
//        printf("\n");
//    }
//}
//
//void Prim(MGraph G, char c) {
//    int min, i, j, k;
//    int start = FindVex(G, c); // ��ʼ�����������е�λ��
//    int lowcost[MAX_VERTICES]; // �洢��С
//    int adj[MAX_VERTICES]; 
//    for (i = 0; i < G.n; i++) {
//        lowcost[i] = G.A[start][i]; // ��ʼ��
//        adj[i] = start; // ǰ���ڵ��ʼ��Ϊ��ʼ��
//    }
//    lowcost[start] = 0; 
//    for (i = 0; i < G.n - 1; i++) {
//        min = 99999; 
//        k = -1;
//        // ����
//        for (j = 0; j < G.n; j++) {
//            if (lowcost[j] != 0 && lowcost[j] < min) { 
//                min = lowcost[j];
//                k = j;
//            }
//        }
//        if (k == -1) {
//            break; 
//        }
//        printf("(%c, %c) Ȩֵ: %d\n", G.vex[adj[k]], G.vex[k], min);
//        lowcost[k] = 0; 
//        for (j = 0; j < G.n; j++) {
//            if (lowcost[j] != 0 && G.A[k][j] < lowcost[j]) {
//                lowcost[j] = G.A[k][j];
//                adj[j] = k;
//            }
//        }
//    }
//}
